# Database ASME 2025

- Materiali: 2532
- Righe identità da tabelle ammesse (6A–6D escluse): 10709; curve meccaniche: 9390; valori di tensione: 149029
- Note definite: 414, distinte per tabella di origine.
- Con valori S1/S2/Sb1/Sb2 ma senza Sy: 43; senza Su: 74; senza entrambi: 285.
- Fra questi, 259 hanno possibili curve sotto identità diverse; 143 non hanno candidati secondo i criteri conservativi del tool.
- Segnalazioni di copertura dimensionale Sy/Su: 1103.

S1 = 1A + 1B; S2 = 5A + 5B; Sb1 = Table 3; Sb2 = Table 4. Temperature in °C, tensioni in MPa, dimensioni in mm.
MAIN è univoca per Specification, Grade, ClassConditionTemper e UNS; 6A–6D sono ignorate. ProductForm appartiene solo alle curve S1/S2. Le varianti di curva e le righe ammesse sono conservate. Note generali e specifiche restano collegate alla propria tabella, senza confondere codici uguali di tabelle differenti.

`material-changes.csv` confronta le identità con il database precedente. Una rimozione indica assenza dalle tabelle sorgenti, non una cancellazione normativa confermata. Le possibili varianti di identità sono segnalate e non fuse automaticamente. Con il database legacy il confronto dei valori precedenti non è disponibile; con un database prodotto dal tool, `source-row-changes.csv` identifica anche righe aggiunte/rimosse/modificate tramite impronte. `note-changes.csv` confronta separatamente i testi delle note, anche quando i valori delle curve non cambiano. `blank-revision-rows.csv` conserva le righe vuote con revisione senza inventarne l'identità.

`missing-strength.csv` distingue Sy, Su ed entrambi mancanti per identità esatta; `size-coverage.csv` aggiunge il controllo degli intervalli dimensionali. `issues.csv` riporta dati incoerenti, note non risolte e minimi non scalari. Le restrizioni scritte nelle note richiedono comunque lettura tecnica.

La nominal composition è unica in MAIN quando coerente. Notazioni con gli stessi elementi in diverso ordine sono equivalenti; composizioni effettivamente discordanti restano NULL e sono documentate in `composition-conflicts.csv`, senza duplicare il materiale. I minimi sono conservati in `Property_Source.MinYieldMPa/MinTensileMPa`; in `Main` sono NULL quando mancanti o differenti fra righe. Nessun valore viene inventato. Le altre proprietà restano non importate. `main-mechanical.csv` conserva ogni riga MAIN con i conteggi delle sei famiglie e le sole assenze applicabili. `main-bolting.csv` controlla Sy/Su/Sb1/Sb2, `main-nonbolting.csv` Sy/Su/S1/S2; le identità condivise compaiono in entrambi. Il report testuale termina al prospetto fisico, senza MissingData; `main-physical.csv` indica E, Alpha, c, k, a, density e Nu presenti nel database, comprese le costanti density/Nu. Un NO non prova una mancanza nella norma ASME.

Verificati conteggi sorgente/database, integrità SQLite, chiavi esterne e coerenza del report di assenza Sy/Su. Dettagli completi in `summary.json`.
