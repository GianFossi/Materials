ASME 2025 - importazione completa dei dati normativi forniti

Console F# .NET 8: dotnet console/MaterialLibrary.DatabaseUpdater.dll --help
Creazione: dotnet console/MaterialLibrary.DatabaseUpdater.dll --sourcedir /directory/export --newdatabasefile nuovo.db --report nuovo-report.txt
Confronto in sola lettura: dotnet console/MaterialLibrary.DatabaseUpdater.dll --sourcedir /directory/export --compare asme_materials_2025.db
Verifica indipendente: python verify-import.py

MAIN: 2532 identita uniche sui quattro campi. Tabelle 6A-6D escluse.
ASME_Data: 2336 materiali; ASME_Data_Source: 30507 campi originali.
Note: 414 testi completi (66 generali, 348 specifici); 10 documenti notes.txt integrali.
748 conflitti scalari normativi conservati per riga e segnalati nei CSV.
NP e limiti qualificati non diventano temperature incondizionate.
Time_Dependent_Start_Temp non viene inventata dalla tipografia persa nei CSV.
Report: BOLTING Sy/Su/Sb1/Sb2; altri Sy/Su/S1/S2; ultima sezione proprieta fisiche, ultima colonna Nu.
Le proprieta fisiche restano fuori dall'importazione corrente.
