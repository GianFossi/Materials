ASME 2025 - MAIN univoca sui quattro campi

Console F# .NET 8: dotnet console/MaterialLibrary.DatabaseUpdater.dll --help
Creazione: dotnet console/MaterialLibrary.DatabaseUpdater.dll --sourcedir /directory/export --newdatabasefile nuovo.db --report nuovo-report.txt
Confronto in sola lettura: dotnet console/MaterialLibrary.DatabaseUpdater.dll --sourcedir /directory/export --compare asme_materials_2025.db

Il report termina al prospetto fisico, ultima colonna Nu.
BOLTING: Sy/Su/Sb1/Sb2. Altri product form: Sy/Su/S1/S2.
MAIN: 2532 identita; BOLTING: 184; altri: 2394; condivisi: 46.
Tabelle 6A-6D escluse. Le altre proprieta fisiche non sono ancora importate.
Note e diagnostica dettagliata nei CSV, incluse 8 composizioni discordanti.
Database e report precedenti non sono stati modificati.
