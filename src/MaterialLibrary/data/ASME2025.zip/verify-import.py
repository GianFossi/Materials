"""Independently verify regulatory scalars, source evidence and complete note documents."""
from pathlib import Path
import argparse,collections,csv,hashlib,io,json,re,sqlite3,zipfile
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--directory',type=Path,default=Path(__file__).resolve().parent)
args=parser.parse_args();root=args.directory
db=root/'asme_materials_2025.db';archive=root/'ASME Database.zip'
c=sqlite3.connect(f'file:{db}?mode=ro',uri=True)
fields={'P-No.':'P_Number','Group No.':'Group_Number','External Pressure Chart No.':'External_Pressure_Chart_No'}
for section,dest in [('I','I'),('III','III'),('VIII-1','VIII_1'),('VIII-2','VIII_2'),('XII','XII')]:fields[section+'—Applic. and Max. Temp. Limit (°C)']='Max_Temp_Sect_'+dest
missing={'','…','...','—','–'}
def norm(value):return re.sub(r'\s+',' ',value.strip().replace('—','-').replace('–','-').replace('−','-').replace('\u00a0',' ')).upper()
def decode(data):
 try:return data.decode('utf-8-sig')
 except UnicodeDecodeError:return data.decode('cp1252')
def numeric(raw):
 if not re.fullmatch(r'[+-]?(?:\d+(?:[.,]\d*)?|\.\d+)(?:[eE][+-]?\d+)?',raw.strip()):return None
 return float(raw.replace(',','.'))
source={(file,line):(mid,table,json.loads(raw)) for mid,table,file,line,raw in c.execute('select id_main,SourceTable,File,CsvLine,RawFieldsJson from Material_Source')}
expected={};by_material=collections.defaultdict(lambda:collections.defaultdict(list));documents=0
with zipfile.ZipFile(archive) as z:
 for name in z.namelist():
  table=name.split('/')[0]
  if table in {'6A','6B','6C','6D'} or not name.lower().endswith('.csv'):continue
  reader=csv.reader(io.StringIO(decode(z.read(name))));header=None
  while True:
   line=reader.line_num+1
   try:record=next(reader)
   except StopIteration:break
   if 'Spec. No.' in record:header=record;continue
   if header is None or not record:continue
   raw=dict(zip(header,[v[2:-1] if v.startswith('="') and v.endswith('"') else v for v in record]))
   if raw.get('Spec. No.','').strip() in missing:continue
   mid,actual_table,actual_raw=source[name,line]
   assert actual_table==table and actual_raw==raw,(name,line)
   for source_field,column in fields.items():
    value=raw.get(source_field,'')
    if value.strip() in missing:continue
    numeric_value=numeric(value) if column.startswith('Max_Temp') else None
    expected[name,line,column]=(mid,table,value,numeric_value)
    by_material[mid][column].append(value)
 for table,contents,sha in c.execute('select SourceTable,Contents,SHA256 from Source_Documents'):
  name=next(n for n in z.namelist() if n.lower()==(table+'/notes.txt').lower());data=z.read(name)
  assert contents==decode(data) and hashlib.sha256(data).hexdigest()==sha
  documents+=1
actual={(file,line,column):(mid,table,value,num) for mid,table,file,line,column,value,num in c.execute('select id_main,SourceTable,File,CsvLine,FieldName,RawValue,NumericValue from ASME_Data_Source')}
assert expected==actual,'Regulatory provenance mismatch'
c.row_factory=sqlite3.Row
rows=c.execute('select * from ASME_Data').fetchall()
assert len(rows)==len(by_material)
for row in rows:
 for column in fields.values():
  values=by_material[row['id_main']][column]
  if column.startswith('Max_Temp'):
   numbers=[numeric(v) for v in values]
   scalar=numbers[0] if numbers and None not in numbers and len(set(numbers))==1 else None
  else:
   unique={norm(v):v for v in values}
   scalar=next(iter(unique.values())) if len(unique)==1 else None
  assert row[column]==scalar,(row['id_main'],column,row[column],values)
 assert row['Time_Dependent_Start_Temp'] is None
for table,code,kind,text in c.execute('select SourceTable,Code,Kind,NoteText from Source_Notes'):
 document=c.execute('select Contents from Source_Documents where SourceTable=?',(table,)).fetchone()[0]
 assert text.strip() and all(line in document for line in text.splitlines()),(table,code)
assert c.execute('pragma integrity_check').fetchone()[0]=='ok'
assert not c.execute('pragma foreign_key_check').fetchall()
result={'regulatory_materials':len(rows),'regulatory_source_fields_verified':len(actual),'note_documents_verified_against_zip':documents,'full_note_texts_verified':c.execute('select count(*) from Source_Notes').fetchone()[0],'main_materials':c.execute('select count(*) from Main').fetchone()[0],'mechanical_values':c.execute('select count(*) from Property_Values').fetchone()[0],'integrity_check':'ok','foreign_key_check':'ok','database_sha256':hashlib.sha256(db.read_bytes()).hexdigest()}
(root/'regulatory-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
