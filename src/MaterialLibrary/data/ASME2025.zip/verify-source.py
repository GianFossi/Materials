from pathlib import Path
import zipfile,csv,io,sqlite3,re,json,hashlib,collections
repo=Path('/workspace/Materials');root=repo/'artifacts/database-2025-four-field-final'
archive=repo/'artifacts/database-2025/ASME Database.zip'
p=root/'asme_materials_2025.db';c=sqlite3.connect(f'file:{p}?mode=ro',uri=True)
mechanical={'Sy','Su','1A','1B','5A','5B','3','4'}
source={(f,line):(mid,table,json.loads(raw)) for mid,table,f,line,raw in c.execute('select id_main,SourceTable,File,CsvLine,RawFieldsJson from Material_Source')}
props={(f,line):(pid,table,json.loads(raw)) for pid,table,f,line,raw in c.execute('select id_property,SourceTable,File,CsvLine,RawFieldsJson from Property_Source')}
omitted={(f,line):json.loads(raw) for f,line,raw in c.execute('select File,CsvLine,RawFieldsJson from Import_Omitted_Rows')}
identities={mid:tuple(json.loads(key)) for mid,key in c.execute('select id_main,NaturalKey from Material_Identity')}
values=collections.defaultdict(list)
for pid,temp,value in c.execute('select id_property,Temperature,StressValue from Property_Values order by Temperature'):values[pid].append((temp,value))
expected_keys=set();expected_counts=collections.Counter();mechanical_counts=collections.Counter();points=0;blank=0
notes={}
def norm(s):
 s=s.strip()
 if s in ['','…','...','—','–']:return ''
 return re.sub(r'\s+',' ',s.replace('–','-').replace('—','-').replace('−','-').replace('\u00a0',' ')).upper()
def decode(b):
 try:return b.decode('utf-8-sig')
 except UnicodeDecodeError:return b.decode('cp1252')
with zipfile.ZipFile(archive) as z:
 for name in z.namelist():
  if not name.lower().endswith('.csv'):continue
  table=name.split('/')[0]
  if table in {'6A','6B','6C','6D'}:continue
  reader=csv.reader(io.StringIO(decode(z.read(name))));header=None
  while True:
   line=reader.line_num+1
   try:row=next(reader)
   except StopIteration:break
   if 'Spec. No.' in row:header=row;continue
   if header is None or not row:continue
   fields=dict(zip(header,[v[2:-1] if v.startswith('="') and v.endswith('"') else v for v in row]))
   if not norm(fields['Spec. No.']):
    assert omitted[(name,line)]==fields;blank+=1;continue
   key=(norm(fields.get('Spec. No.','')),norm(fields.get('Type/Grade','')),norm(fields.get('Class/Condition/Temper',fields.get('Class/Cond./Temper',''))),norm(fields.get('Alloy Desig./UNS No.','')))
   expected_keys.add(key);expected_counts[table]+=1
   mid,actual_table,raw=source[(name,line)]
   assert actual_table==table and raw==fields and identities[mid]==key,(name,line)
   if table in mechanical:
    mechanical_counts[table]+=1
    pid,pt,pr=props[(name,line)];assert pt==table and pr==fields
    expected=sorted((float(re.search(r'<=(-?[0-9.]+)',k).group(1)),float(v.replace(',','.'))) for k,v in fields.items() if '°C, MPa' in k and v not in ['…',''])
    assert values[pid]==expected,(name,line)
    points+=len(expected)
   else:assert (name,line) not in props,(name,line)
 for table,contents,sha in c.execute('select SourceTable,Contents,SHA256 from Source_Documents'):
  name=next(n for n in z.namelist() if n.lower()==(table+'/notes.txt').lower());data=z.read(name)
  assert contents==decode(data) and sha==hashlib.sha256(data).hexdigest()
assert expected_keys==set(identities.values()) and len(expected_keys)==2532
assert sum(expected_counts.values())==len(source)==10709
assert sum(mechanical_counts.values())==len(props)==9390
assert points==149029 and blank==len(omitted)==43
for name,table in [('Sb1','3'),('Sb2','4')]:
 assert c.execute(f'select count(*) from {name}').fetchone()[0]==expected_counts[table]
 assert c.execute(f'''select count(*) from {name} b join Property_Source s on s.id_property=b.id_property
  join Material_Properties p on p.id=b.id_property where s.SourceTable!=? or p.PropertyCode!=? or p.id_main!=b.id_main or p.id_size!=b.id_size''',(table,name)).fetchone()[0]==0
assert c.execute('pragma integrity_check').fetchall()==[('ok',)]
assert not c.execute('pragma foreign_key_check').fetchall()
for name in ['main-mechanical.csv','main-physical.csv']:
 rows=list(csv.DictReader(open(root/'reports'/name,encoding='utf-8-sig')))
 assert len(rows)==len(expected_keys)
 assert len({r['MaterialKey'] for r in rows})==len(expected_keys)
for name in ['main-mechanical.csv','main-physical.csv']:
 assert (root/'reports'/name).stat().st_size>0
for name in ['E','Alpha','c','k','a','density','Nu']:
 assert c.execute(f'select count(*) from VW_Main_Physical_Availability where "{name}"').fetchone()[0]==0
assert not c.execute("select 1 from Material_Source where SourceTable in ('6A','6B','6C','6D')").fetchall()
assert not c.execute("select 1 from Material_Properties where PropertyCode not in ('S1','S2') and ProductForm is not null").fetchall()
assert 'ProductForm' not in [r[1] for r in c.execute('pragma table_info(Main)')]
assert not c.execute("select 1 from Main group by Specification,coalesce(Grade,''),coalesce(ClassConditionTemper,''),coalesce(AlloyDesignation,'') having count(*)>1").fetchall()
with open(root/'reports/main-physical.csv',encoding='utf-8-sig') as f: assert next(csv.reader(f))[-1]=='Nu'
text=(root/'report.txt').read_text()
assert 'MissingData' not in text and 'INCONGRUENZE E DIAGNOSTICA' not in text
assert len(text.split('MAIN - PRESENZA E, Alpha, c, k, a, density, Nu')[1].strip().splitlines())==2534
c.close()
baseline=repo/'artifacts/database-2025/ASME_Materials_2025.db'
old=json.load(open(repo/'artifacts/database-2025/independent-verification.json'))['database_sha256']
assert hashlib.sha256(baseline.read_bytes()).hexdigest()==old
result={'main_union_exact':True,'source_table_count':len(expected_counts),'main_materials':len(expected_keys),'all_source_rows_verified':len(source),'mechanical_rows_verified':len(props),'mechanical_values_verified':points,'blank_revision_rows':blank,'source_counts':dict(expected_counts),'Sb1_rows':expected_counts['3'],'Sb2_rows':expected_counts['4'],'full_main_matrices_verified':True,'all_note_documents_exact':True,'physical_data_present':False,'integrity_check':'ok','foreign_key_check':'ok','previous_database_unchanged':True,'database_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(root/'independent-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
